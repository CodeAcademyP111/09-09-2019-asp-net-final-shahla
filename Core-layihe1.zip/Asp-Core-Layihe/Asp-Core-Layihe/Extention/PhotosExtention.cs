﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.Extention
{
    public static class PhotosExtention
    {
        public static bool IsImage(this IFormFile formFile)
        {
            return (formFile.ContentType.Contains(@"image/"));
        }

        public static bool CheckImageSize(this IFormFile formfile, int MaxSize)
        {
            return (formfile.Length / 1024 / 1024 < MaxSize);

        }

        public async static Task<string> CopyImage(this IFormFile file, string root, string folder)
        {
            string path = Path.Combine(root, "img");
            string filename = Path.Combine(folder, Guid.NewGuid().ToString() + file.FileName);
            string resultPath = Path.Combine(path, filename);

            using (FileStream fileStream = new FileStream(resultPath, FileMode.Create))
            {
                await file.CopyToAsync(fileStream);
            }

            string replaced_filename = filename.Replace(@"\", "/");
            return replaced_filename;
        }
    }
}
