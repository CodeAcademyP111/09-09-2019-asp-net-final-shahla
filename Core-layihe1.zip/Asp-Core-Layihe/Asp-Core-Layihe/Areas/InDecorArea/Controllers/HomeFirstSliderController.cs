﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Asp_Core_Layihe.DAL;
using Asp_Core_Layihe.Extention;
using Asp_Core_Layihe.Models;
using Asp_Core_Layihe.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Asp_Core_Layihe.Areas.InDecorArea.Controllers
{
    [Area("InDecorArea")]
    public class HomeFirstSliderController : Controller
    {
        private AppDbContext _context;
        private IHostingEnvironment _env;
        public HomeFirstSliderController(AppDbContext context,IHostingEnvironment env)
        {
            _context = context;
            _env = env;

        }
        public IActionResult Index()
        {
            return View(_context.HomeSliders);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(HomeSlider homeSlider)
        {
            if (ModelState["Photo"].ValidationState == ModelValidationState.Invalid || ModelState["Title"].ValidationState == ModelValidationState.Invalid || ModelState["Description"].ValidationState == ModelValidationState.Invalid)
            {
                return View();
            }

            if (!homeSlider.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Must be Image type");
                return View();
            }

            if (!homeSlider.Photo.CheckImageSize(2))
            {
                ModelState.AddModelError("Photo", "Image size is large");
                return View();
            }
            string fileName = await homeSlider.Photo.CopyImage(_env.WebRootPath, "slider");

            homeSlider.Image = fileName;
            await _context.HomeSliders.AddAsync(homeSlider);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null) return NotFound();
            HomeSlider slider = await _context.HomeSliders.FindAsync(id);
            if (slider == null) return NotFound();

            return View(slider);
        }

        public async Task<IActionResult> Delete(int? id)
        {

            if (id == null) return NotFound();
            HomeSlider homeSlider = await _context.HomeSliders.FindAsync(id);
            if (homeSlider == null) return NotFound();

            return View(homeSlider);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]

        public async Task<IActionResult> DeleteImage(int? id)
        {
            HomeSlider homeSlider = await _context.HomeSliders.FindAsync(id);
            Utility.DeleteImage(_env.WebRootPath, homeSlider.Image);
            _context.HomeSliders.Remove(homeSlider);
            await _context.SaveChangesAsync();


            return RedirectToAction(nameof(Index));

        }

        public async Task<IActionResult> Update(int? id)
        {
            if (id == null) return NotFound();
            HomeSlider homeSlider = await _context.HomeSliders.FindAsync(id);
            if (homeSlider == null) return NotFound();

            return View(homeSlider);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int id, HomeSlider image)
        {
            HomeSlider dbSlider = await _context.HomeSliders.FindAsync(id);

            if (dbSlider == null)
            {
                return (RedirectToAction(nameof(Index)));
            }
            if (ModelState["Title"].ValidationState == ModelValidationState.Invalid || ModelState["Description"].ValidationState == ModelValidationState.Invalid)
            {
                return View(dbSlider);
            }

            if (image.UpdatePhoto != null)
            {
                if (!image.UpdatePhoto.IsImage())
                {
                    ModelState.AddModelError("Photo", "Must be Image type");
                    return View();
                }

                if (!image.UpdatePhoto.CheckImageSize(2))
                {
                    ModelState.AddModelError("Photo", "Image size is large");
                    return View();
                }

                string fileName = await image.UpdatePhoto.CopyImage(_env.WebRootPath, "slider");
                Utility.DeleteImage(_env.WebRootPath, dbSlider.Image);
                dbSlider.Image = fileName;

            }
            dbSlider.Title = image.Title;
            dbSlider.Description = image.Description;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
