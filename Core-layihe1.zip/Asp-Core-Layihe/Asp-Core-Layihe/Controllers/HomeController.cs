﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Asp_Core_Layihe.DAL;
using Asp_Core_Layihe.Models;
using Asp_Core_Layihe.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Asp_Core_Layihe.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext _context;
        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            
            HomeModel homeModel = new HomeModel
            {
                HomeSliders=_context.HomeSliders,
                FeatureSections=_context.FeatureSections,
                HomeTitles=_context.HomeTitles,
              Titles=_context.Titles,
              BackImages=_context.BackImages,
              OurCollections=_context.OurCollections,
              BrandsIcons=_context.BrandsIcons,
              Products=_context.Products,
              Categories = _context.Categories,
                ProductColors = _context.ProductColors
            };
            return View(homeModel);
        }

        public IActionResult ProductSlider()
        {
            //var catid = _context.Categories.Find(1);
            //var model = _context.Products;
            //return PartialView("_ProductsPartial", model);
            return Json(_context.Products.Where(p=>p.CategoriesId==p.Categories.Id).Select(p => new
            {
                p.CategoriesId,
                p.Name,
                p.ProductColor
            }));


        }

    }
}
