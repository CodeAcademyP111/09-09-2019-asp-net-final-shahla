﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Asp_Core_Layihe.DAL;
using Asp_Core_Layihe.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Asp_Core_Layihe.Controllers
{
    public class LoginRegisterController : Controller
    {
        private AppDbContext _context;
        private UserManager<AppUser> _userManager;
        public LoginRegisterController(AppDbContext context,UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        public IActionResult Register()
        {
            //LoginRegisterModel loginRegisterModel = new LoginRegisterModel
            //{
            //    AllHeadPageImages=_context.AllHeadPageImages
            //};
            return View();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(LoginRegisterModel register)
        {
            if (!ModelState.IsValid) return NotFound(register);
            AppUser appUser = new AppUser
            {UserName=register.UserName,
            Email=register.Email,
            

            };
            IdentityResult identityResult = await _userManager.CreateAsync(appUser,register.Password);

            return (RedirectToAction("Index", "Home"));
           
        }
    }
}