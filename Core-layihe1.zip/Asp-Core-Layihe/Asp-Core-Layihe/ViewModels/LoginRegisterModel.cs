﻿using Asp_Core_Layihe.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.ViewModels
{
    public class LoginRegisterModel
    {
     public IEnumerable<AllHeadPageImage> AllHeadPageImages { get; set; }
        [Required(ErrorMessage ="Cann't null!"),StringLength(10,ErrorMessage =" Not more than 10 simvol")]
        public string UserName { get; set; }
        [Required,DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required,DataType(DataType.Password)]
        public string Password { get; set; }
        [Required,Compare(nameof(Password)),DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}
