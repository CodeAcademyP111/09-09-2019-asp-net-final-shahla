﻿using Asp_Core_Layihe.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.ViewModels
{
    public class HomeModel

   {
        public IEnumerable<HomeSlider> HomeSliders { get; set; }
        public IEnumerable<FeatureSection> FeatureSections { get; set; }

        public IEnumerable<HomeTitles> HomeTitles { get; set; }

       public IEnumerable<Title> Titles { get; set; }
        public IEnumerable<BackImage> BackImages { get; set; }

        public IEnumerable<OurCollection> OurCollections { get; set; }
        public IEnumerable<BrandsIcon> BrandsIcons { get; set; }
        public IEnumerable<Product> Products { get; set; }
        public IEnumerable<Categories> Categories { get; set; }
        public IEnumerable<ProductColor> ProductColors { get; set; }
    }
}
