﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.Models
{
    public class Product
    {
        public int  Id { get; set; }

        [Required(ErrorMessage = "Cann't null!"), StringLength(30, ErrorMessage = "Not more than 30 simvol")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Cann't null!"), StringLength(300, ErrorMessage = "Not more than 300 simvol")]
        public string Description { get; set; }
        [Required,StringLength(250)]
        public string Image { get; set; }
        [Required(ErrorMessage = "Cann't null!")]
        public double RegularPrice { get; set; }
     
        public double NowPrice { get; set; }

        public double DisCountPercent { get; set; }

        public bool New { get; set; }

        public int ViewCount { get; set; }

        public int SaleCount { get; set; }

        public int CategoriesId { get; set; }


        public virtual Categories Categories { get; set; }

        public int ProductColorId { get; set; }

        public virtual ProductColor ProductColor { get; set; }

       



    }
}
