﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.Models
{
    public class HomeTitles
  {
        public int Id { get; set; }
        [Required(ErrorMessage = "Cann't null"), StringLength(30, ErrorMessage = "Not more than 30 simvol")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Cann't null"), StringLength(30, ErrorMessage = "Not more than 50 simvol")]
        public string SubTitle { get; set; }
    }
}
