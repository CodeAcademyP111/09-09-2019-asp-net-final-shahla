﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AspCoreLayihe.Migrations
{
    public partial class CreateIdentity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_Products_Categories_CategoryId",
            //    table: "Products");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_Products_Colors_ColorId",
            //    table: "Products");

            //migrationBuilder.DropTable(
            //    name: "Colors");

            //migrationBuilder.RenameColumn(
            //    name: "SellCount",
            //    table: "Products",
            //    newName: "SaleCount");

            //migrationBuilder.RenameColumn(
            //    name: "SalePercent",
            //    table: "Products",
            //    newName: "DisCountPercent");

            //migrationBuilder.RenameColumn(
            //    name: "ColorId",
            //    table: "Products",
            //    newName: "ProductColorId");

            //migrationBuilder.RenameColumn(
            //    name: "CategoryId",
            //    table: "Products",
            //    newName: "CategoriesId");

            //migrationBuilder.RenameIndex(
            //    name: "IX_Products_ColorId",
            //    table: "Products",
            //    newName: "IX_Products_ProductColorId");

            //migrationBuilder.RenameIndex(
            //    name: "IX_Products_CategoryId",
            //    table: "Products",
            //    newName: "IX_Products_CategoriesId");

            //migrationBuilder.RenameColumn(
            //    name: "Name",
            //    table: "Categories",
            //    newName: "CategoriesName");

            //migrationBuilder.AlterColumn<string>(
            //    name: "Image",
            //    table: "Products",
            //    maxLength: 250,
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldMaxLength: 200);

            //migrationBuilder.AlterColumn<string>(
            //    name: "Description",
            //    table: "Products",
            //    maxLength: 300,
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldMaxLength: 250);

            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "AspNetUsers",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Company",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Country",
                table: "AspNetUsers",
                maxLength: 70,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "AspNetUsers",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PostCode",
                table: "AspNetUsers",
                maxLength: 30,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "State",
                table: "AspNetUsers",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Surname",
                table: "AspNetUsers",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            //migrationBuilder.CreateTable(
            //    name: "ProductColors",
            //    columns: table => new
            //    {
            //        Id = table.Column<int>(nullable: false)
            //            .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            //        Color = table.Column<string>(nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_ProductColors", x => x.Id);
            //    });

            //migrationBuilder.AddForeignKey(
            //    name: "FK_Products_Categories_CategoriesId",
            //    table: "Products",
            //    column: "CategoriesId",
            //    principalTable: "Categories",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Products_ProductColors_ProductColorId",
                table: "Products",
                column: "ProductColorId",
                principalTable: "ProductColors",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_Products_Categories_CategoriesId",
            //    table: "Products");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_Products_ProductColors_ProductColorId",
            //    table: "Products");

            //migrationBuilder.DropTable(
            //    name: "ProductColors");

            migrationBuilder.DropColumn(
                name: "Address",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Company",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Country",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "PostCode",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "State",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Surname",
                table: "AspNetUsers");

            //migrationBuilder.RenameColumn(
            //    name: "SaleCount",
            //    table: "Products",
            //    newName: "SellCount");

            //migrationBuilder.RenameColumn(
            //    name: "ProductColorId",
            //    table: "Products",
            //    newName: "ColorId");

            //migrationBuilder.RenameColumn(
            //    name: "DisCountPercent",
            //    table: "Products",
            //    newName: "SalePercent");

            //migrationBuilder.RenameColumn(
            //    name: "CategoriesId",
            //    table: "Products",
            //    newName: "CategoryId");

            //migrationBuilder.RenameIndex(
            //    name: "IX_Products_ProductColorId",
            //    table: "Products",
            //    newName: "IX_Products_ColorId");

            //migrationBuilder.RenameIndex(
            //    name: "IX_Products_CategoriesId",
            //    table: "Products",
            //    newName: "IX_Products_CategoryId");

            //migrationBuilder.RenameColumn(
            //    name: "CategoriesName",
            //    table: "Categories",
            //    newName: "Name");

            //migrationBuilder.AlterColumn<string>(
            //    name: "Image",
            //    table: "Products",
            //    maxLength: 200,
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldMaxLength: 250);

            //migrationBuilder.AlterColumn<string>(
            //    name: "Description",
            //    table: "Products",
            //    maxLength: 250,
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldMaxLength: 300);

            //migrationBuilder.CreateTable(
            //    name: "Colors",
            //    columns: table => new
            //    {
            //        Id = table.Column<int>(nullable: false)
            //            .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            //        Name = table.Column<string>(maxLength: 20, nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_Colors", x => x.Id);
            //    });

            //migrationBuilder.AddForeignKey(
            //    name: "FK_Products_Categories_CategoryId",
            //    table: "Products",
            //    column: "CategoryId",
            //    principalTable: "Categories",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);

            //migrationBuilder.AddForeignKey(
            //    name: "FK_Products_Colors_ColorId",
            //    table: "Products",
            //    column: "ColorId",
            //    principalTable: "Colors",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);
        }
    }
}
