﻿using Asp_Core_Layihe.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.DAL
{
    public class AppDbContext:IdentityDbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext>options):base(options)
        {

        }

      public  DbSet<HomeSlider> HomeSliders { get; set; }
      public DbSet<FeatureSection> FeatureSections { get; set; }
 
      public DbSet<HomeTitles> HomeTitles { get; set; }

     public DbSet<Title> Titles { get; set; }
        public DbSet<BackImage> BackImages { get; set; }

        public DbSet<HomeSlider2> HomeSlider2s { get; set; }

    }
}
