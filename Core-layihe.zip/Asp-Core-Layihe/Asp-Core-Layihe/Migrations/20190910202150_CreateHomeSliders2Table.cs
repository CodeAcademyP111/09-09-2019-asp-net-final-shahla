﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AspCoreLayihe.Migrations
{
    public partial class CreateHomeSliders2Table : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "HomeSlider2s",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Title = table.Column<string>(maxLength: 30, nullable: false),
                    SubTitle = table.Column<string>(maxLength: 70, nullable: false),
                    Description = table.Column<string>(maxLength: 100, nullable: false),
                    NowPrice = table.Column<double>(nullable: false),
                    RegularPrice = table.Column<double>(nullable: false),
                    DesCount = table.Column<byte>(nullable: false),
                    Image = table.Column<string>(maxLength: 200, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HomeSlider2s", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "HomeSlider2s");
        }
    }
}
