﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Asp_Core_Layihe.DAL;
using Asp_Core_Layihe.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Asp_Core_Layihe.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext _context;
        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            
            HomeModel homeModel = new HomeModel
            {
                HomeSliders=_context.HomeSliders,
                FeatureSections=_context.FeatureSections,
                HomeTitles=_context.HomeTitles,
              Titles=_context.Titles,
              BackImages=_context.BackImages,
              OurCollections=_context.OurCollections,
              BrandsIcons=_context.BrandsIcons,
              Products=_context.Products,
              Categories = _context.Categories,
                ProductColors = _context.ProductColors
            };
            return View(homeModel);
        }

        public IActionResult ProductSlider(int id)
        {
            var t = _context.Categories.Find(id);
            
           string n=JsonConvert.SerializeObject(t.Products.ToList());
            return Content(n);
        }
     
    }
}
