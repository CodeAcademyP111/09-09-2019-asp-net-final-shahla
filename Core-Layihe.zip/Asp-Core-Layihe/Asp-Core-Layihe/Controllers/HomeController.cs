﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Asp_Core_Layihe.DAL;
using Asp_Core_Layihe.ViewModels;
using Microsoft.AspNetCore.Mvc;


namespace Asp_Core_Layihe.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext _context;
        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            //var t=  _context.Categories.Find(1);
            //t.Products.ToList();
            HomeModel homeModel = new HomeModel
            {
                HomeSliders=_context.HomeSliders,
                FeatureSections=_context.FeatureSections,
                HomeTitles=_context.HomeTitles,
              Titles=_context.Titles,
              BackImages=_context.BackImages,
              OurCollections=_context.OurCollections,
              BrandsIcons=_context.BrandsIcons,
              Products=_context.Products,
              Categories=_context.Categories,
              Colors=_context.Colors
            };
            return View(homeModel);
        }
     
    }
}
