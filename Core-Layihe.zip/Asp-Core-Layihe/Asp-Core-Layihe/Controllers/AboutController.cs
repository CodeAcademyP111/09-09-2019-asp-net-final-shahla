﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Asp_Core_Layihe.DAL;
using Asp_Core_Layihe.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace Asp_Core_Layihe.Controllers
{
    
    public class AboutController : Controller
    {
        private AppDbContext _context;
        public AboutController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            AboutModel aboutModel = new AboutModel
            {
                AllHeadPageImages =_context.AllHeadPageImages,
                AboutOurCompanies=_context.AboutOurCompanies,
                OurTeams=_context.OurTeams

            };
            return View(aboutModel);
        }
    }
}