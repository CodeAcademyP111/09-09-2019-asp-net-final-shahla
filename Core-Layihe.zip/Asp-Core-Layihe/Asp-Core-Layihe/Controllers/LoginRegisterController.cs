﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Asp_Core_Layihe.DAL;
using Asp_Core_Layihe.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace Asp_Core_Layihe.Controllers
{
    public class LoginRegisterController : Controller
    {
        private AppDbContext _context;
        public LoginRegisterController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            LoginRegisterModel loginRegisterModel = new LoginRegisterModel
            {
                AllHeadPageImages=_context.AllHeadPageImages
            };
            return View(loginRegisterModel);
        }
    }
}