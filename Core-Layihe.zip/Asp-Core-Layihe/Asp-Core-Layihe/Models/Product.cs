﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.Models
{
    public class Product
    {
        public int  Id { get; set; }

        [Required(ErrorMessage = "Cann't null!"), StringLength(30, ErrorMessage = "Not more than 30 simvol")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Cann't null!"), StringLength(250, ErrorMessage = "Not more than 250 simvol")]
        public string Description { get; set; }
        [Required,StringLength(200)]
        public string Image { get; set; }
       
        public double RegularPrice { get; set; }
        [Required(ErrorMessage = "Cann't null!")]
        public double NowPrice { get; set; }

        public double SalePercent { get; set; }

        public bool New { get; set; }

        public int ViewCount { get; set; }

        public int SellCount { get; set; }

        public int CategoryId { get; set; }


        public virtual Category Category { get; set; }

        public int ColorId { get; set; }

        public virtual Color Color { get; set; }

        public string Active { get; set; }



    }
}
