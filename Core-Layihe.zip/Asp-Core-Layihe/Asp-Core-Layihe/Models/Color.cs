﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.Models
{
    public class Color
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Cann't null!"), StringLength(20, ErrorMessage = "Not more than 20 simvol")]
        public string Name { get; set; }
    }
}
