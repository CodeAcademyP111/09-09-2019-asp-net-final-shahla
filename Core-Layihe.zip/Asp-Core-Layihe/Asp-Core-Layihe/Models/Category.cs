﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.Models
{
    public class Category
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Cann't null!"), StringLength(30, ErrorMessage = "Not more than 30 simvol")]
        public string  Name { get; set; }

        public virtual ICollection<Product> Products { get; set; }
        public string Active { get; set; }
    }
}
