﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.Models
{
    public class SliderSale
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public double Discount { get; set; }
        public double NowPrice { get; set; }
        public double RegularPrice { get; set; }
        public string Description { get; set; }
    }
}
