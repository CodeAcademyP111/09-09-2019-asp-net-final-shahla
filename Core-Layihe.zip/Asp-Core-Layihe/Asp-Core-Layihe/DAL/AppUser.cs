﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.DAL
{
    public class AppUser:IdentityUser
    {
       
        [Required(ErrorMessage ="Cann't null"),StringLength(40,ErrorMessage = "Not more than 40 simvol")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Cann't null"), StringLength(50, ErrorMessage = "Not more than 50 simvol")]
        public string Surname { get; set; }
        [Required(ErrorMessage = "Cann't null"), StringLength(70, ErrorMessage = "Not more than 70 simvol")]
        public string Country { get; set; }
        public string Company { get; set; }
        [Required(ErrorMessage = "Cann't null")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Cann't null"), StringLength(40, ErrorMessage = "Not more than 40 simvol")]
        public string State { get; set; }
        [Required(ErrorMessage = "Cann't null"), StringLength(30, ErrorMessage = "Not more than 30 simvol")]
        public string PostCode { get; set; }
        [Required,DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required,DataType(DataType.Password)]
        public string Password { get; set; }
        [Required, DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
        [Required,StringLength(40)]
        public string Phone { get; set; }

    }
}
