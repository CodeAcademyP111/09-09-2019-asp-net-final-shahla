﻿using Asp_Core_Layihe.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.DAL
{
    public class AppDbContext:IdentityDbContext<AppUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext>options):base(options)
        {

        }

      public  DbSet<HomeSlider> HomeSliders { get; set; }
      public DbSet<FeatureSection> FeatureSections { get; set; }
 
      public DbSet<HomeTitles> HomeTitles { get; set; }

     public DbSet<Title> Titles { get; set; }
        public DbSet<BackImage> BackImages { get; set; }

       public DbSet<OurCollection> OurCollections { get; set; }

        public DbSet<BrandsIcon> BrandsIcons { get; set; }

        public DbSet<AllHeadPageImage> AllHeadPageImages { get; set; }

        public DbSet<AboutOurCompany> AboutOurCompanies { get; set; }

        public DbSet<OurTeam> OurTeams { get; set; }

        public DbSet<Product> Products { get; set; }
        public DbSet<Categories> Categories { get; set; }
        public DbSet<ProductColor> ProductColors { get; set; }
    }
}
