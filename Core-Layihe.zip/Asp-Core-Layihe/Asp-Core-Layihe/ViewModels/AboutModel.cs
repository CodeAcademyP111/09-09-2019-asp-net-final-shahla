﻿using Asp_Core_Layihe.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp_Core_Layihe.ViewModels
{
    public class AboutModel
{      public IEnumerable<AllHeadPageImage> AllHeadPageImages { get; set; }
        public IEnumerable<AboutOurCompany> AboutOurCompanies { get; set; }

        public IEnumerable<OurTeam> OurTeams { get; set; }

    }
}
